<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://kit.fontawesome.com/c5ceb244fe.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="style.css">
    <title>Notes-Prerequisite</title>
</head>
<body>
    <div class="container">
        <div class="navbar">
            <div class="logo"><img src="image/logo.png" ><p>Crystal Academy</p></div>
            <nav>
                <ul id="menuList">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="index.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/Tutorial.php">Tutorial</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="notes.php">Notes</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="contact.php">Contact</a>
                    </li>
                    <li>
                        <button class="btn2" id="dark">Dark mode</button>
                        <button class="btn2" id="login" onclick="window.location.href='signup.php';">signup</button>
                        <button class="btn2" id="signin" onclick="window.location.href='login.php';">Login</button>
                </ul>
            </nav>
            <!-- <a class="btn btn-primary" href="#navigation-main" aria-label="Skip to main navigation">
                <i class="fa fa-bars" aria-hidden="true" onclick="togglemenu() "></i>
            </a> -->
            <!-- <i id="menu-icon" class="fa fa-bars" style="font-size:24px" onclick="togglemenu()"></i> -->
        </div>
        <hr>
        <div class="navbar1">
            <nav>
                <ul id="menuList">
                    <li class="nav-item">
                        <a class="nav-link" href="HTML.php">HTML</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="CSS.php">CSS</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="JAVASCRIPT.php">JAVASCRIPT</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="REACTJS.php">REACT JS</a>
                    </li>
                </ul>
            </nav>
        </div>
        <div class="notes">
            <div class="notes1">
                <ul><h2>INTRODUCTION</h2><br>
                    <a href="notes.php">HTML Introduction</a><br>
                    <a href="working.php">HTML Working</a><br>
                    <a href="Prerequisite.php">HTML Prerequisite</a><br>
                    <a href="">HTML Document Structure</a><br>
                    <a href="">HTML Page Structure</a><br>
                    <a href="">HTML Editors</a><br>
                    <a href="">HTML View Source</a><br>
                    <a href="">HTML Tags</a><br>
                    <a href="">HTML  Elements</a><br><br>
                <h2>HTML BASIC TAGS</h2><br>
                    <a href="">Skeletal Tags</a><br>
                    <a href="">Heading Tags</a><br>
                    <a href="">Paragraph Tag</a><br>
                    <a href="">Horizontal Line Tag</a><br>
                    <a href="">Line Break Tag</a><br>
                    <a href="">Center Tag</a><br>
                    <a href="">HTML View Source</a><br>
                    <a href="">Preserve Formatting Tag</a><br>
                    <br>
                <h2>HTML QUOTATIONS</h2><br>
                    <a href="">Blockquote Tag</a><br>
                    <a href="">Quote Tag</a><br>
                    <a href="">Text Citation Tag</a><br>
                    <a href="">Text Direction Tag</a><br>
                    <a href="">Address Text Tag</a><br>
                    <a href="">Code Tag</a><br>
                    <br>
                </div>
                </ul>
            <div class="notes2">
                <ul><h2>HTML Working</h2><br>
                    <p>When we want to access any information on the internet we search that on a web browser. The web browser gets all the content from the web servers. This content is stored in the webservers in the form of an HTML document.</p>
                    <p>An HTML document is first written with some tags in any code editor or your choice of a text editor and then saved with the <b>“ .html ” </b> extension. After this, the browser interprets the HTML document, reads it, and renders a web page.</p><br>
                    <img src="image/workingh.png" style="height:225px; width:900px;"><br>
                    <p>In the above figure, we open a simple text editor, then the basic structure is to be written. Now, this file is to be saved with the <b>"index.html"</b>  filename. After saving this file, open this file in your web browser. After opening our webpage will look like as the output.</p><br>
                    <p>Below we'll discuss this line briefly.</p><br>
                    <h2>How does HTML Works?</h2><br><br>
                    <h2>HTML Document:</h2><br>
                    <p>It's a text document saved with the extension .html or .htm that contains texts and some tags written between "< >" which give the instructions needed to configure the web page.</p>
                    <p>These tags are fixed and definite. About the structure of html document is explained further.</p><br>
                    <h2>Browser:</h2>
                    <ul>
                        <li>A browser is an application that reads HTML documents and renders the webpage</li>
                        <li>They cannot read the content directly where it is stored. To settle this conflict servers are used.</li>
                        <li>A server acts like an intermediate, it patiently listens to the browser's request and executes it.</li>
                        <li>Now the document is delivered to the browser.</li>
                        <li>Browsers support two parts now: parsing and rendering</li>
                        <li>When the browser is in the parsing stage, it receives raw bytes which are converted into characters and these characters are then converted into tokens after that tokens are converted into nodes. Then these nodes are linked in a tree data structure known as DOM(Document Object Model).</li>
                        <li>when the DOM tree structure has been constructed, the browser starts its rendering. Now each node in the DOM tree will be rendered and displayed.</li>
                </ul><br>
                <h2>Rendered Page:</h2>
                <p>
                    The rendered page is the output screen of our HTML Document which is the page displayed on the browser  
                </p><br>
                <h2>
How does the basic website work?</h2>
                <ul>
                    <li>Web Browser(client) requests <a href="www.titlename.com"></a> like websites from the webserver.</li>
                    <li>Webserver in return sends HTML, CSS, and JS files to it.</li>
                    <li>HTML, JS, and CSS files are parsed by a web browser and show you a beautiful website.</li></ul> 

</div>
        </div>
        <footer>
            <div class="footers">
                <div class="footer-content">
                <p>Copyright © 2023. All rights reserved.</p>
                </div>
            <div class="fot-icon">
                <i class="fa-brands fa-facebook fa-2xl" style="color: #0f3a85;"></i>
                <i class="fa-brands fa-instagram fa-2xl" style="color: #d80e8e;"></i>
                <i class="fa-brands fa-linkedin fa-2xl" style="color: #1162ee;"></i>
                <i class="fa-brands fa-twitter fa-2xl" style="color: #0b62f9;"></i>
            </div>
            </div>
        </footer>
</body>
</html>