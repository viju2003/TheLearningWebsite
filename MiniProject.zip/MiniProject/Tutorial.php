<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://kit.fontawesome.com/c5ceb244fe.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="style.css">
    <title>Tutorial</title>
</head>

<body>
    <div class="container">
        <div class="navbar">
            <div class="logo"><img src="image/logo.png" ><p>Crystal Academy</p></div>
            <nav>
                <ul id="menuList">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="index.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="Tutorial.php">Tutorial</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="notes.php">Notes</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="contact.php">Contact</a>
                    </li>
                    <li>
                        <button class="btn2" id="dark">Dark mode</button>
                        <button class="btn2" id="login" onclick="window.location.href='signup.php';">signup</button>
                        <button class="btn2" id="signin" onclick="window.location.href='login.php';">Login</button>
                </ul>
            </nav>
            <!-- <a class="btn btn-primary" href="#navigation-main" aria-label="Skip to main navigation">
                <i class="fa fa-bars" aria-hidden="true" onclick="togglemenu() "></i>
            </a> -->
            <!-- <i id="menu-icon" class="fa fa-bars" style="font-size:24px" onclick="togglemenu()"></i> -->
        </div>
        <hr>
        <div class="navbar1">
            <nav>
                <ul id="menuList">
                    <li class="nav-item">
                        <a class="nav-link" href="notes.php">HTML</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="CSS.php">CSS</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="JAVASCRIPT.php">JAVASCRIPT</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="REACTJS.php">REACT JS</a>
                    </li>
                </ul>
            </nav>
        </div>
        <div class="midle1">
            <p>Tutorials</p>
        </div>
        <section class="section2">
            <div class="div3">
                <div class="card1">
                    <img src="image/html1.png" alt="">
                    <h3>HTML Tutorial</h3>
                    <button class="card-btn"  onclick="window.location.href='notes.php';" >Start Learning!</button>
                </div>
            </div>
            <div class="div3">
                <div class="card1">
                    <img src="image/css1.png" alt="">
                    <h3>CSS Tutorial</h3>
                    <button class="card-btn"  onclick="window.location.href='notes.php';" >Start Learning!</button>
                </div>
            </div>
            <div class="div3">
                <div class="card1">
                    <img src="image/jst.jfif" alt="">
                    <h3>JAVASCRIPT Tutorial</h3>
                    <button class="card-btn"  onclick="window.location.href='notes.php';" >Start Learning!</button>
                </div>
            </div>
            <div class="div3">
                <div class="card1">
                    <img src="image/react1.png" alt="">
                    <h3>REACT JS Torial</h3>
                    <button class="card-btn"  onclick="window.location.href='notes.php';" >Start Learning!</button>
                </div>
            </div>
            <div class="div3">
                <div class="card1">
                    <img src="image/angular.png" alt="">
                    <h3>NODE JS Tutorial</h3>
                    <button class="card-btn"  onclick="window.location.href='notes.php';" >Start Learning!</button>
                </div>
            </div>
            <div class="div3">
                <div class="card1">
                    <img src="image/node.png" alt="">
                    <h3>Angular JS Tutorial</h3>
                    <button class="card-btn"  onclick="window.location.href='notes.php';" >Start Learning!</button>
                </div>
            </div>
            <div class="div3">
                <div class="card1">
                    <img src="image/php.png" alt="">
                    <h3>PHP Tutorial</h3>
                    <button class="card-btn"  onclick="window.location.href='notes.php';" >Start Learning!</button>
                </div>
            </div>
            <div class="div3">
                <div class="card1">
                    <img src="image/sql.jfif" alt="">
                    <h3>SQL Tutorial</h3>
                    <button class="card-btn"  onclick="window.location.href='notes.php';" >Start Learning!</button>
                </div>
            </div>
            <div class="div3">
                <div class="card1">
                    <img src="image/mongo.jfif" alt="">
                    <h3>Mongo DB Tutorial</h3>
                    <button class="card-btn"  onclick="window.location.href='notes.php';" >Start Learning!</button>
                </div>
            </div>
            <div class="div3">
                <div class="card1">
                    <img src="image/c++.png" alt="">
                    <h3>C++ Tutorial</h3>
                    <button class="card-btn"  onclick="window.location.href='notes.php';" >Start Learning!</button>
                </div>
            </div>
            <div class="div3">
                <div class="card1">
                    <img src="image/java.png" alt="">
                    <h3>Java Tutorial</h3>
                    <button class="card-btn"  onclick="window.location.href='notes.php';" >Start Learning!</button>
                </div>
            </div>
            <div class="div3">
                <div class="card1">
                    <img src="image/py.png" alt="">
                    <h3> Python Tutorial</h3>
                    <button class="card-btn"  onclick="window.location.href='notes.php';" >Start Learning!</button>
                </div>
            </div>
        </section>


<footer>
            <div class="footers">
                <div class="footer-content">
                <p>Copyright © 2023. All rights reserved.</p>
                </div>
            <div class="fot-icon">
                <i class="fa-brands fa-facebook fa-2xl" style="color: #0f3a85;"></i>
                <i class="fa-brands fa-instagram fa-2xl" style="color: #d80e8e;"></i>
                <i class="fa-brands fa-linkedin fa-2xl" style="color: #1162ee;"></i>
                <i class="fa-brands fa-twitter fa-2xl" style="color: #0b62f9;"></i>
            </div>
            </div>
        </footer>



        <script src="/javascript.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe"
            crossorigin="anonymous"></script>

</body>

</html>