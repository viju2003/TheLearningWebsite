<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://kit.fontawesome.com/c5ceb244fe.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="style.css">
    <title>Contact-us</title>
</head>

<body>
    <div class="container">
        <div class="navbar">
            <div class="logo"><img src="image/logo.png">
                <p>Crystal Academy</p>
            </div>
            <nav>
                <ul id="menuList">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="index.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="Tutorial.php">Tutorial</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="notes.php">Notes</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="contact.php">Contact</a>
                    </li>
                    <li>
                        <button class="btn2" id="dark">Dark mode</button>
                        <button class="btn2" id="login" onclick="window.location.href='signup.php';">signup</button>
                        <button class="btn2" id="signin" onclick="window.location.href='login.php';">Login</button>
                    </li>
                </ul>
            </nav>
            <!-- <a class="btn btn-primary" href="#navigation-main" aria-label="Skip to main navigation">
                <i class="fa fa-bars" aria-hidden="true" onclick="togglemenu() "></i>
            </a> -->
            <!-- <i id="menu-icon" class="fa fa-bars" style="font-size:24px" onclick="togglemenu()"></i> -->
        </div>
        <hr>
        <div class="navbar1">
            <nav>
                <ul id="menuList">
                    <li class="nav-item">
                        <a class="nav-link" href="HTML.php">HTML</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="CSS.php">CSS</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="JAVASCRIPT.php">JAVASCRIPT</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="REACTJS.php">REACT JS</a>
                    </li>
                </ul>
            </nav>
        </div>
        <div class="container-fluid">
            <div class="row main-content bg-success text-center">
                <div class="col-md-4 text-center company__info2">
                    <span class="company__logo"></span>
                    <h2 class="company_title1">Let's get in touch</h2>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Fugiat culpa magnam at nemo, consectetur
                        doloremque? Modi ratione quaerat dolores iure.
                    </p>
                    <br>
                    <div class="loacation">
                        <p> <i class="fa-solid fa-location-dot fa-2xl"></i> Lorem ipsum dolor sit amet </p><br>
                        <p><i class="fa-solid fa-envelope fa-xl"></i> Vijaybw321@gmail.com</p><br>
                        <p><i class="fa-solid fa-phone-volume fa-xl"></i> 8669487659</p>
                    </div>
                    <h3>Connect With Us</h3><br>
                    <div class="connect">
                        <i class="fa-brands fa-facebook fa-2xl" style="color: #0f3a85;"></i>
                        <i class="fa-brands fa-instagram fa-2xl" style="color: #d80e8e;"></i>
                        <i class="fa-brands fa-linkedin fa-2xl" style="color: #1162ee;"></i>
                        <i class="fa-brands fa-twitter fa-2xl" style="color: #0b62f9;"></i>
                    </div>

                </div>
                <div class="col-md-8 col-xs-12 col-sm-12 login_form1 ">
                    <div class="container-fluid">
                        <div class="row">
                            <h2> Contact Us</h2>
                            <form action="process.php" method="post">
                        </div>
                        <div class="row">
                            <form control="" class="form-group">
                                <div class="row">
                                    <input type="text" name="UName" placeholder="User Name" class="form__input">
                                </div>
                                <div class="row">
                                    <!-- <span class="fa fa-lock"></span> -->
                                    <input type="text" name="Email" placeholder="Email" class="form__input">
                                </div>
                                <div class="row">
                                    <input type="text" name="Subject" placeholder="Subject" class="form__input">
                                    <textarea name="msg" class="form-control"
                                        placeholder="Write The Massage"></textarea>
                                    <div class="row">
                                    </div>
                                    <button type="submit" class="btn btn-primary">Send</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <footer>
            <div class="footers">
                <div class="footer-content">
                    <p>Copyright © 2023. All rights reserved.</p>
                </div>
                <div class="fot-icon">
                    <i class="fa-brands fa-facebook fa-2xl" style="color: #0f3a85;"></i>
                    <i class="fa-brands fa-instagram fa-2xl" style="color: #d80e8e;"></i>
                    <i class="fa-brands fa-linkedin fa-2xl" style="color: #1162ee;"></i>
                    <i class="fa-brands fa-twitter fa-2xl" style="color: #0b62f9;"></i>
                </div>
            </div>
        </footer>
</body>

</html>