<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://kit.fontawesome.com/c5ceb244fe.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="style.css">
    <title>Welcome-title</title>
</head>

<body>
    <div class="container">
        <div class="navbar">
            <div class="logo"><img src="image/logo.png" ><p>Crystal Academy</p></div>
            <nav>
                <ul id="menuList">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="index.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="Tutorial.php">Tutorial</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="notes.php">Notes</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="contact.php">Contact</a>
                    </li>
                    <li>
                        <button class="btn2" id="dark">Dark mode</button>
                        <button class="btn2" id="login" onclick="window.location.href='signup.php';">signup</button>
                        <button class="btn2" id="signin" onclick="window.location.href='login.php';">Login</button>
                </ul>
            </nav>
            <!-- <a class="btn btn-primary" href="#navigation-main" aria-label="Skip to main navigation">
                <i class="fa fa-bars" aria-hidden="true" onclick="togglemenu() "></i>
            </a> -->
            <!-- <i id="menu-icon" class="fa fa-bars" style="font-size:24px" onclick="togglemenu()"></i> -->
        </div>
        <hr>
        <div class="navbar1">
            <nav>
                <ul id="menuList">
                    <li class="nav-item">
                        <a class="nav-link" href="notes.php">HTML</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="CSS.php">CSS</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="JAVASCRIPT.php">JAVASCRIPT</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="REACTJS.php">REACT JS</a>
                    </li>
                </ul>
            </nav>
        </div>
        <section class="section1">
            <div class="div1">
                <h1>Welcome to </h1>
                <h2>Crystal Academy</h2>
                <h3><b>Learn</b></h3>
                <h3>Web Devlopment</h3>
                <p>Confused on which course to take? I have got you covered. Browse courses and find out the best
                    course
                    for you. Its free!
                    Code With Harry is my attempt to teach basics and those coding techniques to people in short time
                    which
                    took me ages to
                    learn.
                </p>
                <div class="btn1">
                    <button class="btn2" onclick="window.location.href='Tutorial.php';">Free Courses</button>
                    <button class="btn2">Explore blog</button>
                </div>

            </div>
            <div class="div2">
                <img src="image/wt.jpg" class="div2img">
            </div>
        </section>
        <div class="midle ">
            <p>Recommended Courses</p>
        </div>
        <section class="container2">
            <div class="card">
                <img src="image/html.jfif" alt="">
                <div class="card-body">
                    <p>FREE COURSE</p>
                    <h2>HTML</h2>
                    Learn HTML and build your own web pages with our comprehensive online course. Discover the basics of HTML, master advanced techniques, and create stunning websites from scratch. Enroll now and take advantage of our special sale offer!
                </div>
                <button class="card-btn"  onclick="window.location.href='notes.php';" >Start Learning!</button>
            </div>
            <div class="card">
                <img src="image/css.jfif" alt="">
                <div class="card-body">
                    <p>FREE COURSE</p>
                    <h2>CSS</h2>
                    Looking to enhance your web development skills? Take our CSS (Cascading Style Sheets) course and learn how to add style and design to your web pages. Sign up now and take your websites to the next level..
                </div>
                <button class="card-btn">Start Learning!</a></button>
            </div>
            <div class="card">
                <img src="image/javascript1.png" alt="">
                <div class="card-body">
                    <p>FREE COURSE</p>
                    <h2>JAVASCRIPT</h2>
                    beginner to advanced with our comprehensive course. Develop dynamic and interactive web applications and enhance your web development skills. Enroll now and start building your own projects!
                </div>
                <button class="card-btn">Start Learning!</a></button>
            </div>
        </section>
        <footer>
            <div class="footers">
                <div class="footer-content">
                <p>Copyright © 2023. All rights reserved.</p>
                </div>
            <div class="fot-icon">
                <i class="fa-brands fa-facebook fa-2xl" style="color: #0f3a85;"></i>
                <i class="fa-brands fa-instagram fa-2xl" style="color: #d80e8e;"></i>
                <i class="fa-brands fa-linkedin fa-2xl" style="color: #1162ee;"></i>
                <i class="fa-brands fa-twitter fa-2xl" style="color: #0b62f9;"></i>
            </div>
            </div>
        </footer>



        <script src="/javascript.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe"
            crossorigin="anonymous"></script>

</body>

</html>