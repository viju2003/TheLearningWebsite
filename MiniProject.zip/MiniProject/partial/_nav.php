<div class="container">
        <div class="navbar">
            <p>LOGO</p>
            <nav>
                <ul id="menuList">
                    <li class="nav-item">
    <div class="container">
        <div class="navbar">
            <p>LOGO</p>
            <nav>
                <ul id="menuList">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="index.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/Tutorial.php">Tutorial</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/notes.html">Notes</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#Contact">Contact</a>
                    </li>
                    <li>
                        <button class="btn2" id="dark">Dark mode</button>
                        
                        <a class="nav-link" id="login" href="signup.php">signup</a>
                        <a href="login.php" id="login">Login</a></li>
                </ul>
            </nav>      </ul>
            </nav>
            <!-- <a class="btn btn-primary" href="#navigation-main" aria-label="Skip to main navigation">-->
              <!-- <i class="fa fa-bars" aria-hidden="true" onclick="togglemenu() "></i>
            </a> -->
        </div>
        <hr>
        <div class="navbar1">
            <nav>
                <ul id="menuList">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="/image/navbar-png-11.png">Front-End</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/Tutorial.html">Back-End</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/notes.html">Databases</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#Contact">Contact</a>
                    </li>
                </ul>
            </nav>
        </div>