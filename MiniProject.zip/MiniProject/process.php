<?php

require_once "partial/_dbconnect.php";

 $UName = $_POST['UName'];
 $Email = $_POST['Email'];
 $Subject = $_POST['Subject'];
 $msg = $_POST['msg'];
 
//sql stmt to insert values
 $stmt = $link->prepare("insert into feedback(UName, Email, Subject, msg) values(?, ?, ?, ?)");

 //Binds the datatypes with input data 's' for string 'i' for integer
 $stmt->bind_param("ssss", $UName, $Email, $Subject, $msg);
 $stmt->execute();
  if(mysqli_stmt_execute($stmt)){
                // Redirect to login page
                header("location: contact.php");
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }
            
 $stmt->close();
 $link->close();

?>