<?php
// Include config file
require_once "partial/_dbconnect.php";
 
// Define variables and initialize with empty values
$username = $password = $cpassword = "";
$username_err = $password_err = $cpassword_err = "";
 
// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
 
    // Validate username
    if(empty(trim($_POST["username"]))){
        $username_err = "Please enter a username.";
    } elseif(!preg_match('/^[a-zA-Z0-9_]+$/', trim($_POST["username"]))){
        $username_err = "Username can only contain letters, numbers, and underscores.";
    } else{
        // Prepare a select statement
        $sql = "SELECT sno FROM miniproject WHERE username = ?";
        
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "s", $param_username);
            
            // Set parameters
            $param_username = trim($_POST["username"]);
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                /* store result */
                mysqli_stmt_store_result($stmt);
                
                if(mysqli_stmt_num_rows($stmt) == 1){
                    $username_err = "This username is already taken.";
                } else{
                    $username = trim($_POST["username"]);
                }
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }

            // Close statement
            mysqli_stmt_close($stmt);
        }
    }
    
    // Validate password
    if(empty(trim($_POST["password"]))){
        $password_err = "Please enter a password.";     
    } elseif(strlen(trim($_POST["password"])) < 6){
        $password_err = "Password must have atleast 6 characters.";
    } else{
        $password = trim($_POST["password"]);
    }
    
    // Validate confirm password
    if(empty(trim($_POST["cpassword"]))){
        $cpassword_err = "Please confirm password.";     
    } else{
        $cpassword = trim($_POST["cpassword"]);
        if(empty($password_err) && ($password != $cpassword)){
            $cpassword_err = "Password did not match.";
        }
    }
    
    // Check input errors before inserting in database
    if(empty($username_err) && empty($password_err) && empty($cpassword_err)){
        
        // Prepare an insert statement
        $sql = "INSERT INTO miniproject (username, password) VALUES (?, ?)";
         
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "ss", $param_username, $param_password);
            
            // Set parameters
            $param_username = $username;
            $param_password = password_hash($password, PASSWORD_DEFAULT); // Creates a password hash
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Redirect to login page
                header("location: login.php");
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }

            // Close statement
            mysqli_stmt_close($stmt);
        }
    }
    
    // Close connection
    mysqli_close($link);
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://kit.fontawesome.com/c5ceb244fe.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="style.css">
    <title>Sign-in</title>
</head>

<body>
    <?php
//     if($showAlert){
//     echo ' <div class="alert alert-success alert-dismissible fade show" role="alert">
//   <strong>Success!</strong> You account is now created and you can login
// </div>';
// }    
// if($showError){
//     echo ' <div class="alert alert-danger alert-dismissible fade show" role="alert">
//   <strong> Error! </strong>' .$showError.'
// </div> ';
// }
?>

    <div class="container">
        <div class="navbar">
            <div class="logo"><img src="image/logo.png">
                <p>Crystal Academy</p>
            </div>
            <nav>
                <ul id="menuList">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="index.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="Tutorial.php">Tutorial</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="notes.php">Notes</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="contact.php">Contact</a>
                    </li>
                    <li>
                        <button class="btn2" id="dark">Dark mode</button>
                        <button class="btn2" id="login" onclick="window.location.href='signup.php';">signup</button>
                        <button class="btn2" id="signin" onclick="window.location.href='login.php';">Login</button>
                </ul>
            </nav>
            <!-- <a class="btn btn-primary" href="#navigation-main" aria-label="Skip to main navigation">
                <i class="fa fa-bars" aria-hidden="true" onclick="togglemenu() "></i>
            </a> -->
            <!-- <i id="menu-icon" class="fa fa-bars" style="font-size:24px" onclick="togglemenu()"></i> -->
        </div>
        <hr>
        <div class="navbar1">
            <nav>
                <ul id="menuList">
                    <li class="nav-item">
                        <a class="nav-link" href="notes.php">HTML</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="CSS.php">CSS</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="JAVASCRIPT.php">JAVASCRIPT</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="REACTJS.php">REACT JS</a>
                    </li>
                </ul>
            </nav>
        </div>
        <div class="container-fluid">
            <div class="row main-content bg-success text-center">
                <div class="col-md-4 text-center company__info1">
                    <span class="company__logo">
                        <h2><span class="fa fa-android"></span></h2>
                    </span>
                    <h4 class="company_title">Your Company Logo</h4>
                </div>
                <div class="col-md-8 col-xs-12 col-sm-12 login_form1 ">
                    <div class="container-fluid">
                        <div class="row">
                            <h2>Sign in</h2>
                            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                        </div>
                        <div class="row">
                            <div class="row">
                                <input type="text"placeholder="Username" name="username" id="username"
                                    class="form__input <?php echo (!empty($username_err)) ? 'is-invalid' : ''; ?>"
                                    value="<?php echo $username; ?>">
                            </div>
                            <div class="row">
                                <!-- <span class="fa fa-lock"></span> -->
                                <input type="password" placeholder="Password" name="password" id="password"
                                    class="form__input <?php echo (!empty($password_err)) ? 'is-invalid' : ''; ?>"
                                    value="<?php echo $password; ?>">
                            </div>
                            <div class="row">
                                <input type="Password" placeholder="Confirm Password" name="cpassword" id="cpassword"
                                    class="form__input <?php echo (!empty($cpassword_err)) ? 'is-invalid' : ''; ?>"
                                    value="<?php echo $cpassword; ?>">
                                <div id="emailHelp" class="form-text">Make sure to type the same password.</div>
                            </div>
                            <div class="row">
                                <button type="submit" class="btn btn-primary ">Signup</button>
                            </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <footer>
            <div class="footers">
                <div class="footer-content">
                    <p>Copyright © 2023. All rights reserved.</p>
                </div>
                <div class="fot-icon">
                    <i class="fa-brands fa-facebook fa-2xl" style="color: #0f3a85;"></i>
                    <i class="fa-brands fa-instagram fa-2xl" style="color: #d80e8e;"></i>
                    <i class="fa-brands fa-linkedin fa-2xl" style="color: #1162ee;"></i>
                    <i class="fa-brands fa-twitter fa-2xl" style="color: #0b62f9;"></i>
                </div>
            </div>
        </footer>
        <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
            integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous">
        </script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous">
        </script>

</body>

</html>